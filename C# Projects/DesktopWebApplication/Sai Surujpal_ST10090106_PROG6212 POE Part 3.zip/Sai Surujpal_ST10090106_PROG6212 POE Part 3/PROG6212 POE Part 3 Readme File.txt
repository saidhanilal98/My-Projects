Instructions on how to compile and run the software/program:

1. Code a full ASP.NET Core web application. 
2. Click on the top button that says 'IIS Express' or 'Build'.
3. Finally, click on the green play button to run the program or click on the top that says 'Debug' and scroll down to where it says 'Start Without Debugging'.


Brief explaination of how I coded my program with the assignment requirements:

I created the ASP.NET Core web application by using the same database called "Database1" that I have used in my PROG6212 POE Part 2 assignment to build my database and I also made use of
the database in my class library, for example,

        public static string connection_string = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"C:\\Users\\saidh\\source\\repos\\PROGPOE_PART3\\PROGPOE_PART3\\ADO.NET Database\\Database1.mdf\";Integrated Security=True";
        public static string username;

lib.cs 
The changes made in my class library was using the connection string same as my POE in Part 2 and just adding a query in the sql command for the user logging in and adding their credentialss 
where the password would be stored in the database, for example, 

        public static string login(string username)
        {
            string password = "";

            // Creating an object with the ADO.NET connected layer
            using (SqlConnection conn = new SqlConnection(lib.connection_string))
            {
                // Opening the connection to the database
                conn.Open();
                SqlCommand cmd = new SqlCommand("select password from student where username = '" + username + "';", conn);

                try
                {
                    password = Convert.ToString(cmd.ExecuteScalar());
                }
                catch (Exception ex)
                {

                    // Closing the connection to the database
                    conn.Close();
                }
                return password;
            }
        }

The class library uses the database and uses the self study calculations to calculate the self study hours and also stores the hash of the password in the database which links to 
the login page, when the user enters their password it will store that same password as an hash password for security purposes, for example,

        public static int selfstudyCalculations(int numberofCredits, int numberofWeeks, int numberofHours)
        {
            // Self study formula
            int selfstudyHours = (((numberofCredits * 10) / numberofWeeks) - numberofHours);
            return selfstudyHours;
        }

public static string hashPassword(string password)
        {
            var hash = SHA256.Create();

            var asByteArray = Encoding.Default.GetBytes(password);
            var PasswordHash = hash.ComputeHash(asByteArray);

            return Convert.ToBase64String(PasswordHash);
        }

Index.cshtml.cs
For the front end of the design I made use of HTML and CSS code.

Once you run the program it will direct you to the home page where it displays a message saying "TO USE LMNTRIX VARSITY RESOURCES, PLEASE REGISTER OR LOGIN. THANK YOU!".
The user will be able to click on the navigation bar on the top with two options displayed either to register or to login if they have already registered it will driect them 
to the register form or the login form depending on which option the user clicks.

Register.cshtml.cs
For the front end of the design I made use of HTML and CSS code by creating a form for the user to register first before using the systems resources. 

The user will be able to register first by entering their student number, a username, a password of their choice and to also confirm their password. This was created by making 
use of my class libary and my database in my POE Part 2. Using the onPost() method I have used my connection string to store the students details like their student number etc
in the database created for each student, for example,


        public IActionResult OnPost()
        {
            SqlConnection conn = new SqlConnection(lib.connection_string);

            // Establishing connection to database
            conn.Open();

            string sqldata = "insert into student values('" + Request.Form["user_name"] + "','" + Request.Form["user_username"] + "','" + lib.hashPassword(Request.Form["user_password"]) + "');";

            // ADO.NET syntax
            SqlCommand cmd = new SqlCommand(sqldata, conn);
            cmd.ExecuteNonQuery();

            // Closing connection to database
            conn.Close();
            lib.username = Request.Form["user_username"];

            return RedirectToPage("/Modules/displayModules");
        }
    }
}


Login.cshtml.cs

For the front end of the design I also made use of HTML and CSS code by creating a form for the user to login so that they can use the systems resources. 

Once the user has registerd they will be able to login by entering their username and password that they have created when registering. I used the onPost() method to store 
the hash of the password from the class library, for example,

     public IActionResult OnPost()
            {
                string password = lib.hashPassword(Request.Form["user_password"]);
                lib.username = Request.Form["user_username"];

                if (lib.login(Request.Form["user_username"]) == password)
                {
                    return RedirectToPage("/Modules/displayModules");
                }
                else
                {
                    return RedirectToPage("/Error");
                }
            }
        }

display.cshtml.cs
The front end of the design I also made use of HTML and CSS code by creating a table so that the user will be able to see what they have entered on the "List of Modules" page.

Once the user has logged in, it will direct the user to the "List of Modules' page where the user can either click on the "Add module" button or the "Add hours" button.
Using the database, I have implemented a list with a query where the student info table will read the user input on the next page once they have clicked on the "Add module" button, 
this stores the student number, module code, module name, number of credits, class hours, study hours and the number of weeks into that query, for example,

public static List<studentModule> modules = new List<studentModule>();
        public void OnGet()
        {
            modules.Clear();
            SqlConnection connection = new SqlConnection(lib.connection_string);

            using (connection)
            {
                SqlCommand command = new SqlCommand("select * from moduleinfo where username = '" + lib.username + "';", connection);
                connection.Open();

                SqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        studentModule input = new studentModule();
                        input.studentNumber = reader.GetString(0);
                        input.moduleCode = reader.GetString(1);
                        input.moduleName = reader.GetString(2);
                        input.numberOfCredits = reader.GetString(3);
                        input.classHours = reader.GetString(4);
                        input.studyHours = reader.GetInt32(5);
                        input.numberOfWeeks = reader.GetString(6);

                        modules.Add(input);
                    }
                }
                reader.Close();
            }
        }

addModules.cs.html.cs
The front end of the design I also made use of HTML and CSS code by creating a table so that the user will be able to see what they have entered on the "List of Modules" page once 
adding more modules or even one module.

On the "List of Modules" page the user will be able to click on the "Add module" button, once they have clicked that it will direct the user where they will be able to enter 
module code, module name, number of credits, class hours, the number of weeks and the start date of the semester. In the onPost method using the form structue it stores all the data 
by usig a query that inserts the module info values into each input, for example, 

        public IActionResult OnPost()
        {
            SqlConnection conn = new SqlConnection(lib.connection_string);
            conn.Open();
            string query = "insert into moduleinfo values ('" + lib.username + "'" + "," + "'" + Request.Form["user_modulecode"] + "'" 
                                                              + "," + "'" + Request.Form["user_modulename"] + "'" + "," + Int32.Parse(Request.Form["user_numberofcredits"]) + "," 
                                                              + Request.Form["user_classhours"] + "," + lib.selfstudyCalculations(Int32.Parse(Request.Form["user_numberofcredits"]), 
                                                              Int32.Parse(Request.Form["user_numberofweeks"]), Int32.Parse(Request.Form["user_classhours"])) + "," + 
                                                              Int32.Parse(Request.Form["user_numberofweeks"]) + ")";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.ExecuteNonQuery();
            conn.Close();

            return RedirectToPage("/Modules/displayModules");
        }
    }
}

addHours.cs.html
The front end of the design I also made use of HTML and CSS code by creating a table for the headings called module code and the amount of hours they need.

On the "List of Modules" page the user will be able to click on the "Add Hours" button, where the user will be able to enter the module code and the amount of hours they would like to 
add in the onPost() method, and once they click calculate it will automatically calculate the self study hours remaining on the "List of Modules" page. The user will also be 
able to delete their module details if they would like too and re-add a module again, for example, 

public IActionResult OnPost()
        {
            SqlConnection conn = new SqlConnection(lib.connection_string);
            conn.Open();
            string query = "update moduleinfo set studyhours = studyhours - " + Int32.Parse(Request.Form["user_hours"]) + " where modulecode = '" + Request.Form["user_modulecode"] + "'"; 
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.ExecuteNonQuery();
            conn.Close();

            return RedirectToPage("/Modules/displayModules");
        }
        
    }
}




            