Instructions on how to compile and run the software/program:

1. Code a full operational Windows Presentation Foundation(WPF) application. 
2. Click on the top that says 'Build'.
3. Finally, click on the green play button to run the program or click on the top that says 'Debug' and scroll down to where it says 'Start Without Debugging'.


Brief explaination of how I coded my program with the assignment requirements:

MainWindow.xaml.cs
The user will need to register first in order to login. Once the user clicks on the register button, it routes the user to Page 4 where the user will have to fill in their
details like their student number, username, password that they will create and to confirm their password too. Once that is done a message box will appear on the 
same page where it states "You have successfully registered, Please enter your module details on the next page." The user will be able to login with the username 
and password that they have registered with to view their module details. When the user clicks on the login button the program routes the user to Page 2, where the user
can only see their own data that they have entered when registering. When the user clicks on the register button, the program routes the user to Page 4
where the user is able to enter their details as mentioned above.
 
	
Page1.xaml.cs
On this page the user needs to enter all their different module codes, module names, the number of credits that each module has and the class hours.
I created a ADO.NET database that is connected to the list class where each textbox has the list of objects which can be accessed by the 
ADO.NET connected layer, 
for example:

             using (SqlConnection connection = new SqlConnection(conString))
            {
                SqlCommand command = new SqlCommand(
                "select modulecode, modulename, numberofcredits, classhours, studyhours from moduleinfo where username = '" + username +"';", connection);

                connection.Open();

                SqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
              
                        moduleInput.Add(new listClass
                        {
                            Position = Convert.ToString(count),
                            Code = reader["modulecode"].ToString(),
                            Name = reader["modulename"].ToString(),
                            Credits = reader["numberofcredits"].ToString(),
                            Hours = reader["classhours"].ToString(),
                            studyHours = Convert.ToInt32(reader["studyhours"])
                        });

                        count++;
                    }
                }
                else
                {
                    reader.Close();
    
I made use of the cutom class library that contains the self study class related to the information and the self study calculations which is exported into all the other pages.
The user must also enter the number of weeks they have for the whole month and select a date. Once the user has entered all their module details as mentioned above the user
can click the button at the bottom of the right hand corner that displays "Next" which then routes the user to Page 2. The POE required that the password must be stored as a 
hash so I implemented the code where the software stores only the hash of the password in the database, 
for example:  
public static string hashPassword(string password)
        {
            var hash = SHA256.Create();

            var asByteArray = Encoding.Default.GetBytes(password);
            var PasswordHash = hash.ComputeHash(asByteArray);

            return Convert.ToBase64String(PasswordHash);
        }

I created four different queries that inserts the values into the moduleinfo table from the class libary to stores the users details and to display their details 
on page 2.

Page2.xaml.cs
I made use of a LINQ query to manipulate each module input information from the list class for each label content, for example:
            var firstLine = from q in listClass.moduleInput
                       where q.Position == "first"
                       select q;
            foreach (var item in firstLine)
            {
                lblCode1.Content = item.Code;
                lblName1.Content = item.Name;
                lblNumOfCredits1.Content = item.Credits;
                lblClassHours1.Content = item.Hours;


                lblHours1.Content = item.studyHours;


            }
Once the user has read what is displayed on Page 2 the user has an option to click the button at the bottom of the right hand corner that displays "Add Hours" 
which then routes the user to Page 3.

Page3.xaml.cs
On Page 3 the user can enter their module code and the hours and at the bottom of the hours textbox there is a button that displays "Calculate". I made use of the ADO.NET
connected layer by opening the sql connection and using a string query to update the module information that will be set to the study hours of the given module code,
for example:
            string query = "update moduleinfo set studyhours = studyhours - " + Int32.Parse(moduleHours_Textbox.Text) + "where modulecode = '" + moduleCode_Textbox.Text + "'";

The user is able to click on the log in button on the top left corner to return to the main window of the login page or the user can exit the application by clicking on
the 'X' button on the top right corner of page 3.

Page 4.xaml.cs
Created an sql query using the ADO.NET connected layer by inserting the values into the given student table, 
for example:

           string sqlQuery = "insert into student values('" + studentnumber_reg_Textbox.Text + " ', '" + username_reg_Textbox.Text + " ', '" + customClassLib.hashPassword(password_reg_Textbox.Text) + " ')";


Finally I created a updated Unified Modelling Language(UML) class diagram showing the classes in both the class library and the Windows Presentation Foundation(WPF) application.
		
            