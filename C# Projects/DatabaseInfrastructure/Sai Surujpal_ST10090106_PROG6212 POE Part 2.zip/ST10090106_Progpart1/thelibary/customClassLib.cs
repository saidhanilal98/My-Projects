﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace thelibary
{
    public class customClassLib
    {
        /* Self study formula calculations for a student that shows how the number of hours
         * for each module per week is calculated */
        public static int selfstudyCalculations(int numberofCredits, int numberofWeeks, int numberofHours)
        {
            // Self study formula
            int selfstudyHours = (((numberofCredits * 10) / numberofWeeks) - numberofHours);
            return selfstudyHours;
        }

        // Creating a method in the class library for the Sql connection of for the ADO.NET connected layer
        public static void addToDatabase(string queryString, string connectionString)
        {

            // Creating an object with the ADO.NET connected layer
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                // Opening the connection to the database
                connection.Open();

                SqlCommand command = new SqlCommand(queryString, connection);
                command.ExecuteNonQuery();

                // Closing the connection to the database
                connection.Close();
            }
        }


        // The software stores only the hash of the password in the database
        // https://www.youtube.com/watch?v=2yEiwjUEZ78&ab_channel=BugArray
        public static string hashPassword(string password)
        {
            var hash = SHA256.Create();

            var asByteArray = Encoding.Default.GetBytes(password);
            var PasswordHash = hash.ComputeHash(asByteArray);

            return Convert.ToBase64String(PasswordHash);
        }

        // Login Page syntax for the user to use their credentials to log in with use of the ADO.NET connected layer
        public static string login(string username, string connectionString)
        {
            string password = "";

            // Creating an object with the ADO.NET connected layer
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                // Opening the connection to the database
                conn.Open();
                SqlCommand cmd = new SqlCommand("select password from student where username = '" + username + "';", conn);

                try
                {
                    password = Convert.ToString(cmd.ExecuteScalar());
                }
                catch (Exception ex)
                {

                    // Closing the connection to the database
                    conn.Close();
                }

            }

            return password;

        }



    }
}
