﻿
-- Creating a table for student 
CREATE Table student (
studentnumber VARCHAR(10),
username VARCHAR(255),
password VARCHAR(255)
);

-- Select statement for the student table
select * from student

-- Creating a table for the module info
CREATE Table moduleinfo (
username VARCHAR(255),
modulecode VARCHAR(255),
modulename VARCHAR(255),
numberofcredits VARCHAR(255),
classhours VARCHAR(255),
studyhours int,
numberofweeks VARCHAR(255)
);

drop table moduleinfo 

-- Select statement for the module info table
select * from moduleinfo

