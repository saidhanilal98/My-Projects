﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

// Exporting the class library to the main class
using MyClassLibrary;
using thelibary;

namespace ST10090106_Progpart2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public static string username;
        public MainWindow()
        {
            InitializeComponent();
        }
        
        // Allows the user to click on the register button to enter their credentials

        private void register_Click(object sender, RoutedEventArgs e)
        {
            this.Content = new Page4();
        }
        
        // Allows the user to click on the log in button to use the access the applications resources
        private void log_in_Click(object sender, RoutedEventArgs e)
        {

            if (customClassLib.login(username_txt.Text, Properties.Settings.Default.dbConString).ToString() != customClassLib.hashPassword(password_txt.Password).ToString())
            {
               
                username = username_txt.Text;
                this.Content = new Page2();
            }
             else if (customClassLib.login(username_txt.Text, Properties.Settings.Default.dbConString).ToString() == customClassLib.hashPassword(password_txt.Password).ToString())
            {
                username = username_txt.Text;
                this.Content = new Page2();
            }
            
        }


        /* Allows the user to click on the exit button on the top right hand
        * corner to exit the application on the main page */
        private void FinalExitBtn_Main_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }


    }
}