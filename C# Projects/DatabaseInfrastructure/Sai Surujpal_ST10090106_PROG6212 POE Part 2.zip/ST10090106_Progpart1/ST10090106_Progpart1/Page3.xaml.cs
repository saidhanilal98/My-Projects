﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ST10090106_Progpart2
{
    /// <summary>
    /// Interaction logic for Page3.xaml
    /// </summary>
    public partial class Page3 : Page
    {
        public Page3()
        {
            InitializeComponent();
        }
        /* If the user clicks the calculate button then it will display
        * the total amount of self study hours remaining */
        private void Calculate_Click(object sender, RoutedEventArgs e)
        {

            // Creating an object with the ADO.NET connected layer
            SqlConnection connection = new SqlConnection(Properties.Settings.Default.dbConString);

            // Opening the connection to the database
            connection.Open();

            // String query to update the module information that will be set to the study hours of the given module code
            string query = "update moduleinfo set studyhours = studyhours - " + Int32.Parse(moduleHours_Textbox.Text) + "where modulecode = '" + moduleCode_Textbox.Text + "'";
       
            SqlCommand cmd = new SqlCommand(query, connection);
            cmd.ExecuteNonQuery();

            // Closing the connection to the database
            connection.Close();

            Window window = Window.GetWindow(this);
            window.Content = new Page2();

        }
        /* Allows the user to click on the exit button on the top right hand
        * corner to exit the application on the Page 3 because the user does not
        * need to repeatedly add hours everytime they have to access Page 3 */
        private void FinalExitBtn_Page3_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        /* Allows the user to log in from page 3 so that it routes the user to the main window to enter
         * their creditentials and displays the users information on page 2 where they can only see 
         * their own data */
        private void log_in_2_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mw = new MainWindow();
            mw.Show();


        }
    }
}