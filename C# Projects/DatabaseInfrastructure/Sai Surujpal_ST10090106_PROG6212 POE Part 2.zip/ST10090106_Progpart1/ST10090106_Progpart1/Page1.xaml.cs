﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using MyClassLibrary;
using thelibary;

namespace ST10090106_Progpart2
{
    /// <summary>
    /// Interaction logic for Page1.xaml
    /// </summary>
    public partial class Page1 : Page
    {
        public static string weeks;
        public Page1()
        {
            InitializeComponent();
        }

        // Allows the user to click the next button that routes the user to the next page
        private void Next_Click(object sender, RoutedEventArgs e)
        {   
            weeks = NumberofWeeks1.Text;
            
            // Using the query to insert the values into the moduleinfo table from the class libary
            string query = "INSERT INTO moduleinfo VALUES ('" + MainWindow.username + "', '" + moduleCode_Textbox1.Text + "', '" + moduleName_Textbox1.Text + "',  '" + NumberofCredits_Textbox1.Text + "', '" + Int32.Parse(Classhours_Textbox1.Text) + "','" 
                                                              + customClassLib.selfstudyCalculations(Int32.Parse(NumberofCredits_Textbox1.Text), Int32.Parse(Page1.weeks), Int32.Parse(Classhours_Textbox1.Text)) + "', '" + weeks + "');";

            string query2 = "INSERT INTO moduleinfo VALUES ('" + MainWindow.username + "', '" + moduleCode_Textbox2.Text + "', '" + moduleName_Textbox2.Text + "',  '" + NumberofCredits_Textbox2.Text + "', '" + Int32.Parse(Classhours_Textbox2.Text) + "','"
                                                               + customClassLib.selfstudyCalculations(Int32.Parse(NumberofCredits_Textbox2.Text), Int32.Parse(Page1.weeks), Int32.Parse(Classhours_Textbox2.Text)) + "', '" + weeks + "');";

            string query3 = "INSERT INTO moduleinfo VALUES ('" + MainWindow.username + "', '" + moduleCode_Textbox3.Text + "', '" + moduleName_Textbox3.Text + "',  '" + NumberofCredits_Textbox3.Text + "', '" + Int32.Parse(Classhours_Textbox3.Text) + "','"
                                                               + customClassLib.selfstudyCalculations(Int32.Parse(NumberofCredits_Textbox3.Text), Int32.Parse(Page1.weeks), Int32.Parse(Classhours_Textbox3.Text)) + "', '" + weeks + "');";

            string query4 = "INSERT INTO moduleinfo VALUES ('" + MainWindow.username + "', '" + moduleCode_Textbox4.Text + "', '" + moduleName_Textbox4.Text + "',  '" + NumberofCredits_Textbox4.Text + "', '" + Int32.Parse(Classhours_Textbox4.Text) + "','"
                                                               + customClassLib.selfstudyCalculations(Int32.Parse(NumberofCredits_Textbox4.Text), Int32.Parse(Page1.weeks), Int32.Parse(Classhours_Textbox4.Text)) + "', '" + weeks + "');";

            // Displays the module information values for each query
            customClassLib.addToDatabase(query, Properties.Settings.Default.dbConString);

            customClassLib.addToDatabase(query2, Properties.Settings.Default.dbConString);

            customClassLib.addToDatabase(query3, Properties.Settings.Default.dbConString);

            customClassLib.addToDatabase(query4,Properties.Settings.Default.dbConString);

            /* This syntax routes the user to the display page once the user has enetered all their module 
             * information onto page 1 */
            Window window = Window.GetWindow(this);
            window.Content = new Page2();
        }


    }
}