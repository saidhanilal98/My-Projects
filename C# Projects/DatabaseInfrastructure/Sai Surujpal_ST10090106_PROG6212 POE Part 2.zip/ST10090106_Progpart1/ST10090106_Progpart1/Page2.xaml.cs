﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using MyClassLibrary;


namespace ST10090106_Progpart2
{
    /// <summary>
    /// Interaction logic for Page2.xaml
    /// </summary>
    public partial class Page2 : Page
    {
        public Page2()
        {
            InitializeComponent();

            listClass.dataToList(MainWindow.username, Properties.Settings.Default.dbConString);
            /* Applying the LINQ query to manipulate the module input information
            /* from the list class for each label content */
            // Querying the first line of label content of the module input by using the LINQ query
            var firstLine = from q in listClass.moduleInput
                            where q.Position == "0"
                            select q;
            foreach (var item in firstLine)
            {
                lblCode1.Content = item.Code;
                lblName1.Content = item.Name;
                lblNumOfCredits1.Content = item.Credits;
                lblClassHours1.Content = item.Hours;
                lblHours1.Content = item.studyHours;
            }
            // Querying the second line of label content of the module input by using the LINQ query
            var secondLine = from q in listClass.moduleInput
                             where q.Position == "1"
                             select q;
            foreach (var item in secondLine)
            {
                lblCode2.Content = item.Code;
                lblName2.Content = item.Name;
                lblNumOfCredits2.Content = item.Credits;
                lblClassHours2.Content = item.Hours;
                lblHours2.Content = item.studyHours;
            }
            // Querying the third line of label content of the module input by using the LINQ query
            var thirdLine = from q in listClass.moduleInput
                            where q.Position == "2"
                            select q;
            foreach (var item in thirdLine)
            {
                lblCode3.Content = item.Code;
                lblName3.Content = item.Name;
                lblNumOfCredits3.Content = item.Credits;
                lblClassHours3.Content = item.Hours;
                lblHours3.Content = item.studyHours;
            }
            // Querying the forth line of label content of the module input by using the LINQ query
            var forthLine = from q in listClass.moduleInput
                            where q.Position == "3"
                            select q;
            foreach (var item in forthLine)
            {
                lblCode4.Content = item.Code;
                lblName4.Content = item.Name;
                lblNumOfCredits4.Content = item.Credits;
                lblClassHours4.Content = item.Hours;
                lblHours4.Content = item.studyHours;
            }
        }
        /* The user is able to click the add button so that the user is
        * able to add more self study hours on Page 3 */
        private void Add_Click(object sender, RoutedEventArgs e)
        {
            Window window = Window.GetWindow(this);
            window.Content = new Page3();
        }

        // The user is able to click the exit button once they have seen their module details displayed
        private void FinalExitBtn_Main_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }
    }
}