﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Data.SqlClient;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO.Packaging;
using System.Security.Principal;
using System.Security.Cryptography;
using thelibary;


namespace ST10090106_Progpart2
{
    /// <summary>
    /// Interaction logic for Page4.xaml
    /// </summary>
    public partial class Page4 : Page
    {
        public Page4()
        {
            InitializeComponent();
        }

        /* Allows the user to click on the register button to register first in order to 
         * access the applications resources */
        // https://www.youtube.com/watch?v=RUdMXG2kGGE&ab_channel=AmitBParmar
        private void register_Click(object sender, RoutedEventArgs e)
        {

            // Sql query to insert the values into the given student table
           string sqlQuery = "insert into student values('" + studentnumber_reg_Textbox.Text + " ', '" + username_reg_Textbox.Text + " ', '" + customClassLib.hashPassword(password_reg_Textbox.Text) + " ')";

            customClassLib.addToDatabase(sqlQuery, Properties.Settings.Default.dbConString);
            
            // If the user enters all the details for registration then the user has registerd successfully
            MessageBox.Show("You have successfully registered, Please enter your module details on the next page", "Message");

            MainWindow.username = username_reg_Textbox.Text;

            Window window = Window.GetWindow(this);
            Page1 pg = new Page1();
            window.Content = pg; 
        }

        /* Allows the user to click on the exit button on the top right hand
         * corner to exit the application on page 4(Register page) */
        private void FinalExitBtn_Main_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

 
    }
}