﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ST10090106_Progpart2
{
    internal class listClass
    {
        // Created a list for the user to input their values for each module
        public static IList<listClass> moduleInput = new List<listClass>();
        
        // Using the getters and setters method to store the module information
        public string Position { get; set; }
        public string Code { get; set; }
        public string Name { get; set; }
        public string Credits { get; set; }
        public string Hours { get; set; }
        public int studyHours { get; set; }

        //https://learn.microsoft.com/en-us/dotnet/framework/data/adonet/retrieving-data-using-a-datareader
        public static void dataToList(string username,string conString)
        {
            int count = 0;
           
            // Creating an object with the ADO.NET connected layer
            using (SqlConnection connection = new SqlConnection(conString))
            {
                SqlCommand command = new SqlCommand(
                "select modulecode, modulename, numberofcredits, classhours, studyhours from moduleinfo where username = '" + username +"';", connection);

                // Opening the connection to the database
                connection.Open();

                SqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
              
                        moduleInput.Add(new listClass
                        {
                            Position = Convert.ToString(count),
                            Code = reader["modulecode"].ToString(),
                            Name = reader["modulename"].ToString(),
                            Credits = reader["numberofcredits"].ToString(),
                            Hours = reader["classhours"].ToString(),
                            studyHours = Convert.ToInt32(reader["studyhours"])
                        });

                        count++;
                    }
                }
                else
                {
                    reader.Close();
                }
            }
        }

    }
}